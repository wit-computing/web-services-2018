var ContactModel = require('./contact_model');

var query = ContactModel.find( { address: '2 Main Street' }) ;

query.exec( function(err, contacts) {
    if(err) { 
    	console.log(err); 
    } else {
      contacts.forEach( function(c) {
        console.log(c.name) ;
      });
    }
    process.exit() ;
})