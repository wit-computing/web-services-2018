var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/customers_db');

var PostModel = require('./hacker_model');

PostModel.find(function (err, posts) {
    if(err) {
       console.log( err); 
     } else { 
        var comment = {
            body: "I disagree because . . . . . ",
           author: 'doconnor' ,
           upvotes: 0
           } ;
        posts[0].comments.push(comment)
        posts[0].save(function (err) {
            if(err) { 
                console.log(err); 
            } else {
              console.log(posts[0].comments) ;
            }
            process.exit() ;
    });
   }
});
