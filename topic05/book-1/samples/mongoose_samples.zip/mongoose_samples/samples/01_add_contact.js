var ContactModel = require('./contact_model');

var contact = {
  name: 'Phil Jones',
  address: '10 Main Street',
  phone_number: '051-123456'
}

ContactModel.create(contact, function(err, contact) {
    if(err) { 
    	console.log(err); 
    } else {
    	console.log(contact._id);
    }
    process.exit() ;
  });