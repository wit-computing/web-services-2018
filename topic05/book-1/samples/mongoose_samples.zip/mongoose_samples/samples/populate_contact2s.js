var Contact2Model = require('./contact2_model');

Contact2Model.find({}).remove(function() {
     Contact2Model.create(  
		{
		  name: 'Joe Bloggs',
		  address: '1 Main Street',
		  phone_number: '051-123456',
		  county: 'KK',
		  age: 23
		},
		{
		  name: 'Pat Smith',
		  county: 'TY',
		  age: 33,
		  phone_number: '051-234567'
		},
		{
		  name: 'Jane Fleming',
		  address: '2 Main Street',
		  county: 'WX',
		  age: 43,
		  phone_number: '051-345678'
		}, 
		{
		  name: 'Eileen Dwyer',
		  address: '5 Main Street',
		  county: 'WD',
		  age: 30,
		  phone_number: '051-456789'
		}, 
		function() {
              process.exit()
            });
    });