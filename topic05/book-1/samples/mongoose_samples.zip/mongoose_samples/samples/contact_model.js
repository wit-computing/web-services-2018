var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/customers_db');

var Schema = mongoose.Schema;

var ContactSchema = new Schema({
  name: String,
  address: String,
  phone_number: String
});
module.exports = mongoose.model('contacts', ContactSchema);
