var Contact2Model = require('./contact2_model');

var query = Contact2Model
      .where('age').gt(17).lt(66)
      .where('county').in(['KK','WD'])
      .limit(10)
      .sort( {name: +1})
      .select('name phone_number') ;

query.exec( function(err, contacts) {
    if(err) { 
    	console.log(err); 
    } else {
      contacts.forEach( function(c) {
        console.log(c) ;
      });
    }
    process.exit() ;
})