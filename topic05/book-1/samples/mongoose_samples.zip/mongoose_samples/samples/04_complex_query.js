var Contact2Model = require('./contact2_model');

var query = Contact2Model
      .where('age').gt(17).lt(66)
      .where('county').in(['KK','WD']);

query.exec( function(err, contacts) {
    if(err) { 
    	console.log(err); 
    } else {
      contacts.forEach( function(c) {
        console.log(c.name) ;
      });
    }
    process.exit() ;
})