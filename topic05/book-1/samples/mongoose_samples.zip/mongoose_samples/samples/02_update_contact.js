var ContactModel = require('./contact_model');

ContactModel.findOne( {name: 'Joe Bloggs' } , function (err, contact) {
    if(err) { 
      console.log(err); 
    } else if (contact) {
      contact.address = '6 Main Street' ;
      contact.save(function (err) {
          if(err) {
             console.log(err) ; 
           } else {
              console.log('Address updated') ;
           }
        process.exit() ;
      });
    }       
  });