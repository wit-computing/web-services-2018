var Contact2Model = require('./contact2_model');

var query = Contact2Model.find()
      .sort( {name: +1})
      .select('name phone_number') ;

query.exec( function(err, contacts) {
    if(err) { 
    	console.log(err); 
    } else {
      contacts.forEach( function(c) {
        console.log(c) ;
      });
    }
    process.exit() ;
})