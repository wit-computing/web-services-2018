var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/customers_db');

var Schema = mongoose.Schema;

var Contact2Schema = new Schema({
  name: { type: String, required: true }, 
  address: String,
  county: {
      type: String,
      enum: ['WD', 'TY', 'WX', 'KK' ],
      required: true
  },
  age: {type: Number, min: 5, max: 110 },
  phone_number: { type: String, required: true }
});

var Contact2Model = mongoose.model('contact2s', Contact2Schema);

Contact2Schema.path('address').validate(function(value) {
    if (value.length < 5 || value.length > 40 ) {
      return false ;
      }
    return true ;
   }, 'Address must be between 5 and 40 characters long' )

var newContact = {
  name: 'Philip Jones',
  age: 10,
  address: 'home',
  county: 'WX'
}

Contact2Model.create(newContact, function(err, contact) {
    if(err) { 
      // for (key in err.errors) {
      //    console.log('%s: %s', key, err.errors[key].message) ;
      // }
    	console.log(err); 
    } else {
    	console.log(contact._id);
    }
    process.exit() ;
  });



