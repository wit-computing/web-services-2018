var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/customers_db');

var Schema = mongoose.Schema;

var Contact2Schema = new Schema({
  name: { type: String, required: true }, 
  address: String,
  county: {
      type: String,
      enum: ['WD', 'TY', 'WX', 'KK' ],
      required: true
  },
  age: {type: Number, min: 5, max: 110 },
  phone_number: { type: String, required: true }
});
module.exports = mongoose.model('contact2s', Contact2Schema);
