var Contact2Model = require('./contact2_model');

var newContact = {
  name: 'Joe Bloggs',
  age: 140,
  address: '6 Main Street',
  county: 'MN'
}

Contact2Model.create(newContact, function(err, contact) {
    if(err) { 
      for (key in err.errors) {
         console.log('%s: %s', key, err.errors[key].message) ;
      }
    	// console.log(err); 
    } else {
    	console.log(contact._id);
    }
    process.exit() ;
  });