var ContactModel = require('./contact_model');

ContactModel.find({}).remove(function() {
     ContactModel.create(  
		{
		  name: 'Joe Bloggs',
		  address: '1 Main Street',
		  phone_number: '051-123456'
		},
		{
		  name: 'Pat Smith',
		  address: '2 Main Street',
		  phone_number: '051-234567'
		},
		{
		  name: 'Jane Fleming',
		  address: '2 Main Street',
		  phone_number: '051-345678'
		}, 
		function() {
              process.exit()
            });
    });