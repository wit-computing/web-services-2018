// Named exports
export let myVar = 12345;
export let myStr = 'important string';
export const pi = 3.14159526;
export function myFunc() {
  console.log('export function' );
  }