let people = [ { name:'Sheila', credit: 10 },
               { name:'Frank', credit: 20 },
               { name: 'Aoifa',credit: 30 } ] ;
// ES5
people.forEach(function(person) {
    console.log(`${person.name} says Hello!`);
}) ;
// **********************
// ES6
people.forEach( person => console.log(`${person.name} says Hello!`) );
 // Multi-line anonymous function
people.forEach(person => {
	if (person.credit > 25) {
		person.credit += 2;
    }
});
// Multi-parameter anonymous function
let print = (name,credit) => console.log(`${name} has ${credit} credit`) ;
people.forEach(person => print(person.name,person.credit));