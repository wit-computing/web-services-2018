
var foo1 = 10;   // Global scope; let foo1 = 10 ;
if (foo1 > 5) {
	let foo3 = "Beta";
	// .... more code 
}
// console.log(foo3);  // ERROR

// lets can be re-declared as long as 
// its in a different block. 
{
   let foo3 = 'hello' // different block
   console.log(foo3);
}
// --------------------------------

const foo4 = 10;
// foo4 = 12 ;  // ERROR
const cool = { people: ['you', 'me', 'him'] }
cool.people.push('her') //{ people: ['you', 'me', 'him', 'her'] }
// cool = { people: ['them', 'those'] } // ERROR
var uncool = cool ;
uncool = { people: ['donald'] } // vars can be reassigned, s anormal
console.log(uncool); // //{ people: [ 'donald' ] }
console.log(cool);   //{ people: [ 'you', 'me', 'him', 'her' ] }
