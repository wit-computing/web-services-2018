
// ES5 - constructor function
function Point(x, y) {
  this.x = x;
  this.y = y;
  this.print = function() {
     console.log(this.x + ', ' + this.y);
   }
}
let p1 = new Point(1,2);
p1.print() ;
// --------------------------------------
// ES6 - Class
class PointES6 {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  print() {
    console.log(`${this.x}, ${this.y}`);
  }
}
let p2 = new PointES6(2,3);
p2.print();
