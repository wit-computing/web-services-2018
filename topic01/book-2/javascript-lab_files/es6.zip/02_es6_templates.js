
// Interpolation
let f_name = 'Diarmuid' ;
let weight = 12 ;
let kilos = (weight*6.35).toFixed(2)
let text = `My name is ${f_name} and I weigh ${kilos} kilos`;
console.log(text);
let today = new Date();
text = `the time and date is ${today.toLocaleString()}`;
console.log(text);

// Multi-line strings
text = (
`My name is ${f_name} 
and I weigh ${kilos} kilos
as of  ${today.toLocaleString()}
`);
console.log(text);

// Embedded quotes in a string
text = `I'm "amazed" that we have so many quotation marks to choose from!` ;
console.log(text);