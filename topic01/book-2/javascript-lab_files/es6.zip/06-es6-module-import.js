
import {myFunc, myStr} from './05-es6-module-export';
myFunc() ;
console.log(myStr)