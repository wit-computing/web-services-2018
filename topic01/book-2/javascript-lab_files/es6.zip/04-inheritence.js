
class Point {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  print() {
    console.log(`${this.x}, ${this.y}`);
  }
}

class Point3D extends Point {
  constructor(x, y, z) {
    super(x, y); 
    this.z = z;
  }
  print() {
    let output = (
` Point: x ${this.x}, 
        y ${this.y}, 
        z ${this.z}`) ;
    console.log(output);
  }
}

let p1 = new Point3D(1,2,3)
p1.print();    // 1,2,3
p1.x = 6 ; // Set x in p1 
p1.print();    // 6,2,3
p1 instanceof Point3D; // true
p1 instanceof Point; // true
